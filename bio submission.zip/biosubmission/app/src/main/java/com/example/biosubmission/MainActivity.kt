package com.example.biosubmission

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val goofButton = findViewById<Button>(R.id.goofButton)

        goofButton.setOnClickListener {
            val dialogBinding = layoutInflater.inflate(R.layout.goofdialog, null)

            val myDialog = Dialog(this)
            myDialog.setContentView(dialogBinding)

            myDialog.setCancelable(true)
            myDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            myDialog.show()

            val sure = dialogBinding.findViewById<Button>(R.id.sure)
            sure.setOnClickListener {
                myDialog.dismiss()
            }

        }


    }
}